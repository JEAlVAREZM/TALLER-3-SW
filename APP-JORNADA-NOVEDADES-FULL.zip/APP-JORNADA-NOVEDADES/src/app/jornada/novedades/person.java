/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package app.jornada.novedades;

/**
 *
 * @author Publicidad
 */
public class person {
    //abstract and encapsulate
    private String name, id;
    
    //constructor without parameters
    public person() {
    }
    
    //constructor with parameters

    public person(String name, String id) {
        this.name = name;
        this.id = id;
    }
    
    //getter and setter

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }
    
    
    
    
    
    
}
