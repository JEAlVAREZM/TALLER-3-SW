/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package app.jornada.novedades;
import javax.swing.JOptionPane;

public class code {
  
  
    public static void main(String[] args){
    
     boolean repeat = true; 
     
     employe employe1 = new employe();
     counters counter1 = new counters();
     
     employe1.setName(JOptionPane.showInputDialog("Type the name of the employe"));
     employe1.setId(JOptionPane.showInputDialog("Type the id of the employe"));
     employe1.setCompany(JOptionPane.showInputDialog("Type the company of the employe"));
     
     counter1.setCountHours(0);
     counter1.setCountLicency(4);
     counter1.setCountMother(180);
     counter1.setCountFather(15);
     counter1.setCountIncapacities(20);
     counter1.setCountVacation(15);
     
     while(repeat == true){
         //main menu
        String option = JOptionPane.showInputDialog("Type A) to enter working day. B) to enter novelties. C) Exit");   
         switch (option) {
             //option a to register hours
             case "a", "A" -> {
                 String date = JOptionPane.showInputDialog("Type the date in this format: dd-mm-yyyy");
                 double startHour = Double.parseDouble(JOptionPane.showInputDialog("Type the hour in this format hh.mm"));
                 double finalHour = Double.parseDouble(JOptionPane.showInputDialog("Type the hour in this format hh.mm"));
                 double workingTime = finalHour - startHour;
                 if((workingTime + counter1.getCountHours()) >= 8 ){
                     JOptionPane.showMessageDialog(null,"Succesful registration. Worked hours: " + (workingTime + counter1.getCountHours()) + ". At the date: " + date);
                 }
                 else{
                     JOptionPane.showInputDialog("There are hours left to complete the minimum hours. Missing: " + (8-workingTime) + " hours.");
                     counter1.countHours = counter1.countHours + workingTime;
                     
                 }
             }
             //option to gonna second menu
             case "b", "B" -> {
                 String option2 = JOptionPane.showInputDialog("Type the option: 1. Licenses. 2. Inabilities. 3. Vacations. 4. Work permits.");
                 //licencies
                 switch (option2) {
                     case "1" -> {
                         String option3 = JOptionPane.showInputDialog("Type the option: 1. Temporal. 2. Motherhood. 3. Factherhood.");
                         
                         if (option3.equals("1")) {
                             int temporalLicency = Integer.parseInt(JOptionPane.showInputDialog("Type the days of license"));
                             
                             if (counter1.countLicency - temporalLicency <= 4 && counter1.countLicency - temporalLicency >= 0 ) {
                                 JOptionPane.showMessageDialog(null, "Days of license registered succesful. " + "Left days: " + (temporalLicency - counter1.countLicency) );
                                 counter1.countLicency = counter1.countLicency - temporalLicency;
                                 
                             }else
                             {
                                 JOptionPane.showMessageDialog(null, "You reached the limit days of license. Please take vacations");
                                 
                                 
                             }
                             
                         }
                         if (option3.equals("2")) {
                             int motherLicency = Integer.parseInt(JOptionPane.showInputDialog("Type the days of license"));
                             
                             if (counter1.countMother - motherLicency <= 180  && counter1.countMother - motherLicency >= 0 ) {
                                 JOptionPane.showMessageDialog(null, "Days of license registered succesful. " + "Left days: " + (counter1.countMother - motherLicency) );
                                 counter1.countMother = counter1.countMother - motherLicency;
                                 
                             }else
                             {
                                 JOptionPane.showMessageDialog(null, "You reached the limit days of license. Please take vacations");
                                 
                                 
                             }
                             
                         }
                         if (option3.equals("3")) {
                             int fatherLicency = Integer.parseInt(JOptionPane.showInputDialog("Type the days of license"));
                             
                             if (counter1.countFather - fatherLicency <= 15  && counter1.countFather - fatherLicency >= 0 ) {
                                 JOptionPane.showMessageDialog(null, "Days of license registered succesful. " + "Left days: " + (counter1.countFather - fatherLicency) );
                                 counter1.countFather = counter1.countFather - fatherLicency;
                                 
                             }else
                             {
                                 JOptionPane.showMessageDialog(null, "You reached the limit days of license. Please take vacations");
                                 
                                 
                             }
                             
                         }
                     }
                     case "2" -> {
                         int incapacities = Integer.parseInt(JOptionPane.showInputDialog("Type the days of inability. 20 days maximum"));
                         if (counter1.countIncapacities - incapacities <= 20  && counter1.countIncapacities - incapacities >= 0 ){
                             JOptionPane.showMessageDialog(null, "Days of inability registered succesful. " + "left days " + (counter1.countIncapacities - incapacities) );
                             counter1.countIncapacities = counter1.countIncapacities - incapacities;
                             
                         }
                         else{
                             
                             JOptionPane.showMessageDialog(null, "The maximium days are 20. Try again.");
                             
                         }
                     }
                     case "3" -> {
                         int vacations = Integer.parseInt(JOptionPane.showInputDialog("Type the days of vacations"));
                         if (counter1.countVacation - vacations <= 15  && counter1.countVacation - vacations >= 0 ){
                             JOptionPane.showMessageDialog(null, "Days of vocations registered succesful. " + "left days " + (counter1.countVacation - vacations));
                             counter1.countVacation = counter1.countVacation - vacations;
                             
                         }
                         else{
                             
                             JOptionPane.showMessageDialog(null, "The maximium days are 15. Try again ");
                             
                         }
                     }
                     case "4" ->{
                         int permisions = Integer.parseInt(JOptionPane.showInputDialog("Type the requested hours for work permits"));
                         if (permisions <= 5 && permisions >= 1 ){
                             JOptionPane.showMessageDialog(null, "Work permits hours registered sucecesful. " + "Total requested hours: " + permisions);
                             
                         }
                         else{
                             
                             JOptionPane.showMessageDialog(null, "The maximium days are 5. Please ask for a temporal requested or vacations. ");
                             
                         }
                         
                         
                     }
                     default -> {
                     }
                 }
             }
             case "c", "C" -> repeat = false;
             default -> {
             }
         }
            
            
            }
            
            
     }
     
        
    
    }
    
    
