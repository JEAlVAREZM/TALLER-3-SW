/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package app.jornada.novedades;

/**
 *
 * @author Publicidad
 */
//herency
public class employe extends person {
    private String company;

    @Override
    public String toString() {
        return "employe{" + "company=" + company + '}';
    }
    
    //builder with parameters
    public employe() {
    }
    //builder with parameters
    public employe(String company, String name, String id) {
        super(name, id);
        this.company = company;
    }
    
    //getter and setter
    public String getCompany() {
        return company;
    }

    public void setCompany(String company) {
        this.company = company;
    }
    
     
    
}
