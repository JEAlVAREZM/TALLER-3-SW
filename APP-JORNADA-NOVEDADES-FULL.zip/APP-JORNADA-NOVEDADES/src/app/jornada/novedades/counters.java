/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package app.jornada.novedades;

/**
 *
 * @author Publicidad
 */
//polimofirms
public class counters extends employe {
    protected double countHours;
    protected int countLicency;
    protected int countMother; 
    protected int countFather;
    protected int countIncapacities;
    protected int countVacation;
    
    //builder without parameters
    public counters() {
    }
    
    //builder without parameters
    public counters(double countHours, int countLicency, int countMother, int countFather, int countIncapacities, int countVacation, String company, String name, String id) {
        super(company, name, id);
        this.countHours = countHours;
        this.countLicency = countLicency;
        this.countMother = countMother;
        this.countFather = countFather;
        this.countIncapacities = countIncapacities;
        this.countVacation = countVacation;
    }
    
    //getter and setter

    public double getCountHours() {
        return countHours;
    }

    public void setCountHours(double countHours) {
        this.countHours = countHours;
    }

    public int getCountLicency() {
        return countLicency;
    }

    public void setCountLicency(int countLicency) {
        this.countLicency = countLicency;
    }

    public int getCountMother() {
        return countMother;
    }

    public void setCountMother(int countMother) {
        this.countMother = countMother;
    }

    public int getCountFather() {
        return countFather;
    }

    public void setCountFather(int countFather) {
        this.countFather = countFather;
    }

    public int getCountIncapacities() {
        return countIncapacities;
    }

    public void setCountIncapacities(int countIncapacities) {
        this.countIncapacities = countIncapacities;
    }

    public int getCountVacation() {
        return countVacation;
    }

    public void setCountVacation(int countVacation) {
        this.countVacation = countVacation;
    }
    
    
     
    
}
